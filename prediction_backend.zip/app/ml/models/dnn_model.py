import io
import time

import requests
import pandas as pd
from tensorflow.keras import Sequential
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ReduceLROnPlateau
from tensorflow.keras.layers import InputLayer, BatchNormalization, LSTM, Dropout, Dense

from app.core.settings import settings, new_columns, tf_swap
from ml.teaching import preprocess, convert_time, sweden_dataset_preprocess

time_points = settings.time_points
arg_num = settings.arg_num
class_num = settings.class_num
url = settings.url


model = Sequential([
        InputLayer(input_shape=(time_points, arg_num,)),
        BatchNormalization(axis=-1),
        LSTM(120, activation='tanh'),
        Dropout(.1),
        BatchNormalization(),
        Dense(1000, activation='relu'),
        Dropout(.1),
        BatchNormalization(),
        Dense(32, activation='relu'),
        Dense(class_num, activation='softmax')
    ])
model.compile(
    loss='categorical_crossentropy',
    optimizer=Adam(learning_rate=1e-5),
    metrics=['categorical_accuracy'],
)


learning_rate_reduction = ReduceLROnPlateau(
    monitor='val_categorical_accuracy',
    patience=2,
    verbose=1,
    factor=0.8,
    min_lr=0.00001
)
# path = os.path.join('./drive/My Drive/basic_car_weights/')
# path = f'{path}v{model_v}'+'-acc{val_categorical_accuracy:.4f}-val_loss{val_loss:.4f}-ep{epoch:03d}.hdf5'
# print(path)
# model_weights_checkpoint = ModelCheckpoint(
#     path,
#     verbose=1,
#     save_best_only=True,
# )


def train(train_dataset, valid_dataset):
    print(time.strftime('%H:%M:%S'))
    _history = model.fit(
        train_dataset,
        epochs=20,
        verbose=1,
        validation_data=valid_dataset,
        initial_epoch=0,
        callbacks=[
            learning_rate_reduction,
            #model_weights_checkpoint,
        ],
    )
    print(time.strftime('%H:%M:%S'))
    return _history


def post_model(_filename, _history):
    files = {'file': open(f'{settings.dnn_model_path}neuralnetwork_model_{filename}.h5')}
    print(_filename)
    response = requests.post(url, files=files, data={'percent': _history.history['val_categorical_accuracy'][-1]*100})
    print(response.status_code)


while True:
    print(url)
    r = requests.get(url)
    print(r.status_code)

    if r.status_code == requests.codes.ok:
        try:
            filename = r.headers['Content-Disposition'].split(';')[1].split('=')[1]
            filename = filename.replace('"', '').split('.')[0]
            df = pd.read_csv(io.StringIO(r.content.decode('utf-8')), skiprows=1, low_memory=False)
            df.columns = new_columns
            df_copy = df[tf_swap]
            df_copy = df_copy.dropna()
            dataset_train, dataset_valid = preprocess(df_copy, rate=10, time_conv_f=convert_time)
            history = train(dataset_train, dataset_valid)
            model.save(f'{settings.dnn_model_path}neuralnetwork_model_{filename}.h5')
            post_model(filename, history)
        except Exception as e:
            print(f'Ошибка обучения: {e}')
            time.sleep(300)
    else:
        print('Нет данных для обучения')
        time.sleep(300)
