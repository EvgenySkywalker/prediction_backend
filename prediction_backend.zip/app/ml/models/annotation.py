import io

import pandas as pd
import numpy as np
from tensorflow.keras.models import load_model

from app.core.settings import settings, new_columns, tf_swap
from app.models.schema.label import Label


def read_data_csv(file, test):
    try:
        if test:
            copy = pd.read_csv(file, skiprows=2, low_memory=False)
        else:
            copy = pd.read_csv(io.StringIO(file), skiprows=2, low_memory=False)
    except Exception as e:
        raise Exception(f'Чтение файла: {e}')

    try:
        copy.columns = new_columns
        copy = copy[tf_swap]
        copy = copy.dropna()
    except Exception as e:
        raise Exception(f'Формат данных [Количество столбцов != {len(new_columns)}]{e}')

    return copy


d_type = settings.d_type
time_points = settings.time_points
arg_num = settings.arg_num
class_num = settings.class_num


def annotate(file, test=False):
    model = load_model(f'{settings.dnn_model_path}model.h5')
    timestamps, dataset = preprocess(file, test, rate=10, conv=True)

    try:
        labels = model.predict(dataset)
    except Exception as e:
        raise Exception(f'Во время работы алгоритма: {e}')

    try:
        states = get_states(timestamps, labels)
    except Exception as e:
        raise Exception(f'Список пуст: {e}')

    return states


def get_states(timestamps, labels):
    switches = [
        Label(start=timestamps[i * time_points], end='', mode=np.argmax(labels[i]) + 1)
        for i in range(1, len(labels))
        if np.argmax(labels[i]) != np.argmax(labels[i - 1])
    ]

    for i, sw in enumerate(switches[:-1]):
        sw.end = switches[i+1].start
    switches[-1].end = timestamps[-1]

    return (
        [Label(start=timestamps[0], end=switches[0].start, mode=np.argmax(labels[0]) + 1)]
        + switches
    )


def convert_time(time):
    """00:15:41.0000001 -> float"""

    split = time.split(':')
    new_value = float(split[0]) * 60 * 60
    new_value += float(split[1]) * 60
    new_value += float(split[2])
    return new_value


def preprocess(file, test, rate=1, conv=True):
    copy = read_data_csv(file, test)
    copy = copy.iloc[::rate].copy()

    try:
        timestamps = copy['timestamp'].to_numpy()
        if conv:
            copy['timestamp'] = copy['timestamp'].apply(convert_time)
        del copy['label']
        max_idx = copy.shape[0] - copy.shape[0] % time_points
        dataset = copy[:max_idx].to_numpy()
        dataset = dataset.reshape(-1, time_points, arg_num)
    except Exception as e:
        raise Exception(f'Во время обработки данных: {e}')

    return timestamps, dataset
