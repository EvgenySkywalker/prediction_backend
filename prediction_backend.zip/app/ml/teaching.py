import numpy as np
import pandas as pd
from tensorflow.keras.preprocessing import timeseries_dataset_from_array

from app.core.settings import settings

time_points = settings.time_points
arg_num = settings.arg_num
class_num = settings.class_num


def sweden_dataset_preprocess(data_frame):
    copy = data_frame.copy()
    copy = copy[np.all((copy.label.apply(float.is_integer), copy.label != 0), axis=0)]
    
    return copy


def convert_time(str_time):
    """00:15:41.0000001 -> float"""

    split = str_time.split(':')
    new_value = float(split[0]) * 60 * 60
    new_value += float(split[1]) * 60
    new_value += float(split[2])

    return new_value


def preprocess(data_frame: pd.DataFrame, rate: int = 1, time_conv_f=None):
    copy = data_frame.iloc[::rate].copy()

    def get_datasets(dataset, label2):
        dataset_train = timeseries_dataset_from_array(
            dataset,
            label2,
            time_points,
            sampling_rate=1,
            sequence_stride=1,
            batch_size=256,
            shuffle=True,
            seed=40,
            end_index=delimiter,
        )
        dataset_valid = timeseries_dataset_from_array(
            dataset,
            label2,
            time_points,
            sampling_rate=1,
            sequence_stride=1,
            batch_size=256,
            shuffle=True,
            seed=40,
            start_index=delimiter,
        )
        return dataset_train, dataset_valid

    def encode(_label):
        index = int(_label - 1)
        new_label = [0. for _ in range(class_num)]
        new_label[index] = 1.
        return new_label

    if time_conv_f is not None:
        copy['timestamp'] = copy['timestamp'].apply(time_conv_f)

    test = 0.3
    labeled_data = []
    grouped = copy.groupby('label')
    for label, data in grouped:
        del data['label']
        try:
            x = data.to_numpy(copy=True)
            encoded_label = encode(label)
            y = np.array(encoded_label * x.shape[0]).reshape(-1, class_num, 1)
            delimiter = int(x.shape[0] * (1. - test))
            labeled_data += [get_datasets(x, y)]
        except Exception as e:
            print(str(e))

    train_dataset, valid_dataset = labeled_data[0]
    for data in labeled_data[1:]:
        data_train, data_validate = data
        train_dataset = train_dataset.concatenate(data_train)
        valid_dataset = valid_dataset.concatenate(data_validate)

    return train_dataset, valid_dataset
